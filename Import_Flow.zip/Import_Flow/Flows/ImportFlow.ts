import { test, expect, Page} from '@playwright/test';
import { clickAndMeasureDynamic, login, getNextDateTimeFormatted,selectEntityAndSite, getRandomNumberString, readTestArtifact,
  writeTestArtifact, selectFutureDay} from '../utils/test-helpers'; // <-- Update this path if needed, e.g. './utils/test-helpers_VBS_CCIS' or '../../utils/test-helpers_VBS_CCIS'
import { Master,Appointments } from 'Locators/VBSMasters';
import { Import } from 'Locators/BookingLocators';


export async function CSM_ImportBooking_MOTL(
  page: Page,
  data: any,
  bookingNumberFile: string,
  blnNumberFile: string,
  containerNumberFile: string
) {
test.setTimeout(120000); // Set timeout to 2 minutes
await test.step('Login and navigate to Import Booking screen', async () => {
    // await login(page);
    // await selectEntityAndSite(page);
    await clickAndMeasureDynamic(page, Import.CustomerServiceLogo, Import.BookingTabButton, 'Route to Customer Service');
    await clickAndMeasureDynamic(page, Import.BookingTabButton, Import.ImportBookingsButton, 'Route to Booking tab');
    await clickAndMeasureDynamic(page, Import.ImportBookingsButton, Import.AddBookingButton, 'Route to Import booking screen');
    await clickAndMeasureDynamic(page, Import.AddBookingButton, Import.LIGMNumberInput, 'Add Import Booking');
  });

  await test.step('Fill Import Booking details', async () => {
    await page.locator(Import.LIGMNumberInput).fill(getRandomNumberString(15));
    await page.waitForTimeout(1000);
    // await page.locator(Import.LIGMDateInput).type(`${getNextDateTimeFormatted(1).date}`, { delay: 200 });
    await page.locator('//app-site-wall-nz-date-picker[@formcontrolname="LIGMDate"]').click();
    await selectFutureDay(page, 1);
    await page.locator(Import.LineNumberInput).type(getRandomNumberString(5));
    const blnNumber = 'BLN' + getRandomNumberString(10);
    await page.locator(Import.BLNumberInput).type(blnNumber);
    await page.waitForTimeout(1000);
    // await page.locator(Import.BLDateInput).type(`${getNextDateTimeFormatted(1).date}`, { delay: 200 });

    await page.locator('//app-site-wall-nz-date-picker[@formcontrolname="BLDate"]').click();
    await selectFutureDay(page, 1);
    await page.locator(Import.GIGMNumberInput).type(getRandomNumberString(7));
    // await page.locator(Import.GIGMDateInput).type(`${getNextDateTimeFormatted(1).date}`, { delay: 200 });
    await page.locator('//app-site-wall-nz-date-picker[@formcontrolname="GIGMDate"]').click();
    await selectFutureDay(page, 1);
    await page.locator(Import.SMTPNumberInput).type('SMTP' + getRandomNumberString(7));
    await page.locator(Import.TModeTypeSelect).selectOption(data.Transport_Mode);
    await page.locator(Import.TModeAgentInput).type('Transport Mode Agent');
    await page.locator(Import.PortOfLoadingSelect).selectOption(data.PortOfLoading);
    await page.locator(Import.PortOfArrivalSelect).selectOption(data.PortOfArrival);
    await page.locator(Import.BreifCargoDescriptionTextarea).fill('This is an automation test for Import Booking');
    await clickAndMeasureDynamic(page, Import.SubmitBookingButton, Import.UpdateDetailsButton, 'Submit booking details');

    const bookingNumber = (await page.locator(Import.BookingNumberLabel).textContent())?.replace(/\s+/g, '');
    console.log('Booking Number:', bookingNumber);
    console.log('BLN Number:', blnNumber);

    writeTestArtifact(bookingNumberFile, `${bookingNumber}`);
    writeTestArtifact(blnNumberFile, blnNumber);

    await clickAndMeasureDynamic(page, Import.UpdateDetailsButton, Import.BookingDetails, 'Update booking details');
  });

  await test.step('Fill CHA, Operator, Commodity and update booking', async () => {
    await page.locator(Import.CHAAutocompleteInput).fill(data.CHA_Name);
    await page.locator(Import.AutocompleteOption).first().click();

    await page.locator(Import.OperatorAutocompleteInput).fill(data.OperatorID);
    await page.locator(Import.AutocompleteOption).first().click();

    await page.locator(Import.SearchCHAInput).fill(data.CHA_Name);
    await page.locator(Import.AutocompleteOption).first().click();
    await page.locator(Import.CommoditySelect).selectOption(data.Commodity);

    await page.locator(Import.UpdateButton).isVisible();
    await clickAndMeasureDynamic(page, Import.UpdateButton, Import.CargoTabButton, 'Update booking details');
    await page.locator(Import.CargoTabButton).isVisible();
    await clickAndMeasureDynamic(page, Import.CargoTabButton, Import.AddNewCargoButton, 'Add Cargo');
    await clickAndMeasureDynamic(page, Import.AddNewCargoButton, Import.FreightAndPackagesDiv, 'Add Cargo');
  });

  await test.step('Add Cargo details', async () => {
    await page.click(Import.FreightAndPackagesDiv);
    await page.locator(Import.DECWeightInput).fill(data.DECWeight);
    await page.locator(Import.WtMeasUnitSelect).selectOption({ label: `${data.WeightUnit}` });
    await page.locator(Import.DECVolumeInput).fill(data.DECVolume);
    await page.locator(Import.VolMeasUnitSelect).selectOption({ label: `${data.VolumeUnit}` });
    await page.waitForTimeout(1000);
    await page.locator(Import.CANoOfPackageInput).fill(data.Packages);
    await page.locator(Import.CAPackageTypeSelect).selectOption(data.PackageType);

    await clickAndMeasureDynamic(page, Import.AddCargoButton, Import.AddNewCargoButton, 'Submit Add Cargo');
    console.log('Cargo added successfully');
  });

  await test.step('Add Container details', async () => {
    await clickAndMeasureDynamic(page, Import.ContainerTabButton, Import.AddNewContainerButton, 'Route to Container tab');
    await clickAndMeasureDynamic(page, Import.AddNewContainerButton, Import.IGMDetailsDiv, 'Click Add Container');
    await page.click(Import.IGMDetailsDiv);

    const ContainerNo = 'IMPU' + getRandomNumberString(7);
    writeTestArtifact(containerNumberFile, ContainerNo);
    // writeTestArtifact('VBS_Import_Container_Number', ContainerNo);

    await page.locator(Import.ContainerNoInput).fill(ContainerNo);
    await page.locator(Import.COSizeTypeSelect).selectOption({ label: `${data.DepotSizeType}` });
    await page.locator(Import.ISOSizeTypeSelect).selectOption({ label: `${data.ISOSizeType}` });
    await page.locator(Import.LFCLSelect).selectOption({ label: `${data.FreightKind}` });

    await page.locator(Import.DONumberInput).fill('DON' + getRandomNumberString(7));
    const deliveryOrderDate = new Date(Date.now() + 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 16);
    const deliveryValidtyDate = new Date(Date.now() + 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 16);
    // await page.locator(Import.DODateInput).fill(deliveryOrderDate);
    await page.locator('//app-site-wall-nz-date-picker[@formcontrolname="DODate"]').click();
    await selectFutureDay(page, 1);
    // await page.locator(Import.DOValidityDateInput).fill(deliveryValidtyDate);
    await page.locator('//app-site-wall-nz-date-picker[@formcontrolname="DOValidityDate"]').click();
    await selectFutureDay(page, 1);

    await expect(page.locator(Import.ResetButton)).toBeVisible();
    await expect(page.locator(Import.CancelButton)).toBeVisible();
    await clickAndMeasureDynamic(page, Import.UpdateButton, Import.AddNewContainerButton, 'Update Container');
    console.log('Container added successfully');

    // Save ContainerNo for later steps
    (page as any)._containerNo = ContainerNo;
  });

  await test.step('Add BOE and Map Cargo', async () => {
    await clickAndMeasureDynamic(page, Import.CargoTabButton, Import.OpenActions, 'BOE');
    await page.locator(Import.OpenActions).click();
    await clickAndMeasureDynamic(page, Import.BOEListItem, Import.BENumberInput, 'Route to BOE Screen');

    await page.locator(Import.BENumberInput).fill(getRandomNumberString(7));
    // await page.locator(Import.BEDateInput).type(`${getNextDateTimeFormatted(0).date}`, { delay: 200 });
    await page.locator('//app-site-wall-nz-date-picker[@formcontrolname="BEDate"]').click();
    await selectFutureDay(page, 0);

    await clickAndMeasureDynamic(page, Import.UpdateButton, Import.CargoTabButton, 'Update BOE');

    await page.locator(Import.OpenActions).isVisible();
    await page.locator(Import.OpenActions).click();
    // await page.locator(Import.MapListItem).click();
    // await clickAndMeasureDynamic(page, Import.MapListItem, Import.PackagesInput, 'Route to Mapping Screen');
    await clickAndMeasureDynamic(page, Import.MapListItem, Import.PackagesCheckbox, 'Route to Mapping Screen');
    await page.locator(Import.PackagesCheckbox).check();
    await page.locator(Import.PackagesInput).fill(data.Packages);

    await clickAndMeasureDynamic(page, Import.UpdateButton, Import.AddNewCargoButton, 'Map Cargo');
  });

  await test.step('Work Order tab and final assertions', async () => {
    // Retrieve ContainerNo from previous step
    const ContainerNo = (page as any)._containerNo;

    await clickAndMeasureDynamic(page, Import.WorkOrderTabButton, `//td[normalize-space()="${ContainerNo}"]`, 'Route to Work Order tab');
    expect(await page.locator(`//td[normalize-space()="${ContainerNo}"]`).isVisible()).toBeTruthy();
    await clickAndMeasureDynamic(page, Import.EditContainerButton(ContainerNo), Import.WorkOrderSubmitButton, 'Edit Container');
    const WO_Description = await page.locator('select[formcontrolname="JODID"]').textContent();
    await expect(WO_Description).not.toBe('');
    await expect('select[formcontrolname="AllocationUnitID"]').not.toBe('');
    await clickAndMeasureDynamic(page, Import.WorkOrderSubmitButton, `//app-manage-containers//div[normalize-space()="${ContainerNo}"]`, 'Update Container');
    // await page.locator(Import.WorkOrderSubmitButton).click();
    // await expect(page.locator(Import.WorkOrderTransportation)).toBeVisible();
    await page.close();
    console.log('TC002_CS_ImportBooking_MOTL completed successfully');
  });
}